
import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author kobinath
 */
public class print extends javax.swing.JFrame {

    /**
     * Creates new form print1
     */
    public print() {
        initComponents();
    }

    String Regno;
    String ModelN;
    String Mfg;

    String ModelY;
    String KmsT;
    String AD;
    String Price;
    String Tax;

    public print(String repaino, String model, String sn, String price, String pay, String due, String newpay, String bal) throws PrinterException {
        initComponents();

        this.Regno = repaino;
        this.ModelN = model;
        this.Mfg = sn;

        this.ModelY = price;
        this.KmsT = pay;
        this.AD = due;
        this.Price = newpay;
        this.Tax = bal;

        txtbill.setText(txtbill.getText() + "**********VU Car Sales***************\n");
        txtbill.setText(txtbill.getText() + "\n");

        txtbill.setText(txtbill.getText() + " " + "Registered No        : " + Regno + "\n");
        txtbill.setText(txtbill.getText() + " " + "Model Name           : " + ModelN + "\n");
        txtbill.setText(txtbill.getText() + " " + "Manufactured on      : " + Mfg + "\n");
        txtbill.setText(txtbill.getText() + " " + "Model Year           : " + ModelY + "\n");
        txtbill.setText(txtbill.getText() + " " + "Kilometers Travelled : " + KmsT + "\n");
        txtbill.setText(txtbill.getText() + " " + "Additional Details   : " + AD + "\n");

        txtbill.setText(txtbill.getText() + "\n");
        txtbill.setText(txtbill.getText() + "\n");

        txtbill.setText(txtbill.getText() + "      " + "Price : " + Price + "\n");
        txtbill.setText(txtbill.getText() + "      " + "Tax   : " + Tax + "\n");

        txtbill.setText(txtbill.getText() + "*************************************\n");
        txtbill.setText(txtbill.getText() + "*************************************\n");
        txtbill.setText(txtbill.getText() + "Thank you for visiting VU Car Sales! See you again..................\n");

    }

    public void print() {
        try {
            txtbill.print();
        } catch (PrinterException ex) {
            Logger.getLogger(print.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtbill.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        jScrollPane1.setViewportView(txtbill);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(print1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(print1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(print1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(print1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new print().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane txtbill;
    // End of variables declaration//GEN-END:variables
}
